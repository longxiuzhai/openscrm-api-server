# OpenSCRM Go To Java Migration Context

This file is the handoff context for continuing the Go-to-Java migration. Load this file together with `MIGRATION.md` before resuming work.

## Workspace And Runtime

- Repository root: `/Users/gemii/IdeaProjects/api-server`
- Java project root: `/Users/gemii/IdeaProjects/api-server/java-server`
- Original Go code remains under the repository root, mainly `app/`, `pkg/easywework/`, `common/`, `conf/`.
- Maven command: `/Users/gemii/develop/apache-maven-3.6.3/bin/mvn`
- Verification command used after every batch:

```bash
/Users/gemii/develop/apache-maven-3.6.3/bin/mvn -q test
```

- The machine has Java 8 as default, but this project targets Java 11. The Java 11 path was available in previous runs; keep using the existing project Maven setup and verify with the command above.
- `java-server/` is currently untracked as a whole in git, so `git diff` from repo root may not show useful Java changes. Use `find`, `rg`, and direct file reads.

## Confirmed Technical Choices

- Framework: Spring Boot 2.7.x
- Java version: 11
- Database: MySQL
- ORM: MyBatis Plus
- Cache/session: Redis + Spring Session
- Auth token: JWT
- MQ: RabbitMQ
- Delayed message pattern: TTL wait queue + dead-letter ready queue
- WeWork SDK: port current in-repo Go logic into Java, not a third-party SDK.
- Schema: keep raw SQL for now at `src/main/resources/db/schema.sql`; Flyway/Liquibase not introduced yet.

## Migration Principles

- Preserve Go HTTP paths, request fields, response envelope, DB table names, and permission behavior unless explicitly changed.
- Prefer existing Java patterns already created in `java-server`.
- Keep original Go service available while Java is built module by module.
- Add small, focused batches and run Maven tests after each batch.
- Use generated `*Po` entities and `*PoMapper` interfaces under `cn.openscrm.api.persistence`.
- Use `ApiResponse.ok(...)` and `PageResponse<T>` for controller responses.
- Use `CurrentStaffService.requireStaffAdmin(session)` for staff-admin routes.
- Use `@RequirePermission` with `BizIdentity` and `OperationType`.
- Keep compatibility aliases for routes when needed, especially `/staff_admin/...` and `/staff-admin/...`.

## Java Project Structure

- Main application: `cn.openscrm.api.OpenScrmApplication`
- Config: `cn.openscrm.api.config`
- Common response/errors/id/security/mq: `cn.openscrm.api.common`
- Auth/session/RBAC: `cn.openscrm.api.auth`
- WeWork client DTOs and API methods: `cn.openscrm.api.wework`
- WeWork callback decrypt/dispatch/registrars: `cn.openscrm.api.wework.callback`
- Persistence entities: `cn.openscrm.api.persistence.entity`
- Persistence mappers: `cn.openscrm.api.persistence.mapper`
- Migrated business modules:
  - `department`
  - `staff`
  - `role`
  - `permission`
  - `welcome`
  - `tag`
  - `groupchat`
  - `contactway`
  - partial `customer`

## Important Existing Java Files

- `src/main/java/cn/openscrm/api/OpenScrmApplication.java`
- `src/main/java/cn/openscrm/api/config/OpenScrmProperties.java`
- `src/main/java/cn/openscrm/api/config/RabbitMqConfig.java`
- `src/main/java/cn/openscrm/api/common/api/ApiResponse.java`
- `src/main/java/cn/openscrm/api/common/api/PageResponse.java`
- `src/main/java/cn/openscrm/api/common/exception/ErrorCode.java`
- `src/main/java/cn/openscrm/api/common/id/SnowflakeIdGenerator.java`
- `src/main/java/cn/openscrm/api/common/mq/DelayedJobPublisher.java`
- `src/main/java/cn/openscrm/api/common/mq/DelayedJobConsumer.java`
- `src/main/java/cn/openscrm/api/common/mq/DelayedJobTopics.java`
- `src/main/java/cn/openscrm/api/auth/service/CurrentStaffService.java`
- `src/main/java/cn/openscrm/api/auth/service/LoginService.java`
- `src/main/java/cn/openscrm/api/wework/WeWorkClient.java`
- `src/main/java/cn/openscrm/api/wework/DefaultWeWorkClient.java`
- `src/main/java/cn/openscrm/api/wework/callback/WeWorkCallbackService.java`
- `src/main/java/cn/openscrm/api/contactway/service/ContactWayService.java`
- `src/main/java/cn/openscrm/api/contactway/service/ContactWayScheduledTasks.java`
- `src/main/java/cn/openscrm/api/groupchat/service/GroupChatSyncService.java`
- `MIGRATION.md`

## Completed Capabilities

See `MIGRATION.md` for the canonical checklist. As of this handoff, the following broad areas are in place:

- Spring Boot Java project scaffold.
- Full schema SQL and generated 48 persistence entities/mappers.
- Unified API response, errors, global exception handling.
- JWT and Spring Session Redis.
- RabbitMQ TTL + dead-letter delayed queue.
- Staff admin/staff login URL/callback/force-login and session writing.
- RBAC annotation/interceptor.
- Permission and role APIs.
- Department sync/query/tree.
- Staff sync/query/detail/current/enable.
- Welcome message CRUD and department/staff assignment helpers.
- WeWork callback verification/decryption/XML parsing/event registry.
- Callback handlers for department, staff, customer relation, tag, group chat.
- WeWork client methods for access token, departments, staff list/detail/oauth userinfo, external tags, group chat detail, contact way add/get/update/delete.
- Tag sync and delete cleanup.
- Group chat create/update/dismiss callbacks sync local group/member tables.
- Contact way group CRUD.
- Contact way CRUD/batch update, staff/backup/schedule associations, WeWork contact-way sync.
- Contact way delayed refresh publishing/consumer and daily counter reset scheduled task.

## Current MQ/Async State

Rabbit config:

- Exchange: `openscrm.exchange`
- Dead-letter exchange: `openscrm.dead-letter.exchange`
- Wait queue: `openscrm.delayed-job.wait.queue`
- Ready queue: `openscrm.delayed-job.ready.queue`

Topic constants:

- `topic:RefreshContactWayTopic`
- `topic:SyncCustomerDataTopic`

`DelayedJobConsumer` currently:

- Handles `RefreshContactWayTopic` by calling `ContactWayService.refresh(id, extCorpId)`.
- Logs `SyncCustomerDataTopic` because the real customer sync consumer is not migrated yet.

`CustomerCallbackRegistrar` publishes `SyncCustomerDataTopic` when customers are added/edited.

## Contact Way Notes

Relevant Go source:

- `app/controller/contact_way.go`
- `app/controller/contact_way_group.go`
- `app/models/contact_way.go`
- `app/models/contact_way_staff.go`
- `app/models/contact_way_shedule_staff.go`
- `app/services/contact_way.go`
- `app/consumers/contact_way.go`
- `app/tasks/contact_way.go`
- `pkg/easywework/contact_way_api.go`
- `pkg/easywework/contact_way_model.go`

Current Java implementation:

- `contactway/controller/ContactWayController.java`
- `contactway/controller/ContactWayGroupController.java`
- `contactway/service/ContactWayService.java`
- `contactway/service/ContactWayGroupService.java`
- `contactway/service/ContactWayScheduledTasks.java`
- `contactway/dto/*`

Implemented:

- Contact way group query/get/create/update/delete.
- Contact way query/get/create/update/delete/batch-update.
- Local association persistence for normal staff, backup staff, schedules, schedule staff.
- Current effective staff calculation based on:
  - schedule enable
  - staff control online flag
  - daily add customer limit
  - backup staff fallback
  - auto skip verify time window
- WeWork add/update/delete/get contact way.
- Delayed refresh jobs for skip-verify time windows and schedule boundaries.
- Daily reset of `daily_add_customer_count` for normal, backup, and schedule staff.

Not fully implemented yet:

- Add-customer side effects from `ContactWay.DealAddCustomerEvent`:
  - auto tag via WeWork mark tag API
  - customer remark/description update
  - nickname block welcome-message logic
  - channel welcome/default welcome/disable welcome behavior
  - increment contact-way staff daily/total counts
  - trigger refresh when staff reaches daily limit

## Callback Notes

Callback entry:

- `WeWorkCallbackController`
- `WeWorkCallbackService`
- `WeWorkCallbackCrypto`

Registrars currently overwrite default log-only handlers:

- `DepartmentCallbackRegistrar`
- `StaffCallbackRegistrar`
- `CustomerCallbackRegistrar`
- `TagCallbackRegistrar`
- `GroupChatCallbackRegistrar`

Group chat callback implementation:

- `change_external_chat/create`: fetches group detail and syncs group/member list.
- `change_external_chat/update`: fetches group detail and refreshes group/member list; increments daily join/quit count when applicable.
- `change_external_chat/dismiss`: marks group as dismissed.

Customer relation callback implementation currently:

- add/edit publishes `SyncCustomerDataTopic`.
- delete/del-follow creates events/history and soft-deletes relation.
- Real `SyncCustomerDataTopic` consumer still needs to be ported.

## WeWork Client Notes

Java interface: `WeWorkClient`

Current implemented methods include:

- `getAccessToken`
- `listDepartments`
- `listUserIds`
- `getUser`
- `getUserInfo`
- `listExternalContactCorpTags`
- `getGroupChat`
- `addContactWay`
- `getContactWay`
- `updateContactWay`
- `deleteContactWay`
- `updateUserEnable`

Next likely WeWork methods needed:

- external customer detail/batch detail
- customer remark update
- mark external contact tag
- send welcome message
- upload media / image-to-media helpers
- group chat management/list APIs
- material/media APIs
- conversation archive APIs

## High Priority Next Work

Follow this order unless the user redirects:

1. Port `SyncCustomerDataTopic` consumer.
   - Read Go sources: `app/consumers/staff.go`, `app/services/customer*.go`, `app/callback/staff_event/add_customer.go`, `pkg/easywework/external_contact_api.go`.
   - Implement WeWork external contact detail methods.
   - Upsert customer, customer_info, customer_staff relation, tags.
   - Wire welcome-code send flow if enough DTOs exist.

2. Port contact way add-customer side effects.
   - Read `app/services/contact_way.go`, especially `DealAddCustomerEvent`.
   - Implement auto tag, remark/description, nickname block, welcome strategy.
   - Increment staff counts and refresh contact way when daily limit is hit.

3. Port customer frontend current-session helpers.

4. Port welcome message upload-url/image-to-WeWork-media helpers.

5. Port group-chat query/management HTTP APIs.

6. Continue larger modules:
   - quick reply
   - material library
   - mass message
   - group auto-join
   - conversation archive

## Known Gaps And Caveats

- Java `ContactWayService` currently deletes and recreates association rows on update. This is simpler than GORM association replacement and may change IDs for association records.
- Contact way delayed refresh jobs are not de-duplicated. Go generated stable job IDs; Java currently publishes payloads through RabbitMQ TTL without job-id dedupe.
- `SyncCustomerDataTopic` is only logged in Java right now.
- WeWork callback XML parser extracts top-level fields only; current migrated callback events fit this, but nested XML callbacks may require parser improvements.
- Some Java DTO response shapes wrap entities under names like `contactWay` or `contactWayGroup`; if the frontend expects flattened Go model fields, adjust DTO serialization later.
- File storage and DB migration tooling are still undecided.
- Integration tests with real Redis/RabbitMQ/MySQL/WeWork are not present; current verification is Maven test/compile.

## Commands And Search Patterns

Useful commands:

```bash
rg -n "SyncCustomerDataTopic|DealAddCustomerEvent|ExternalContact|WelcomeCode" app pkg java-server/src/main/java
rg -n "ContactWay|contact_way|RefreshContactWayTopic" app pkg java-server/src/main/java
rg --files java-server/src/main/java | sort
/Users/gemii/develop/apache-maven-3.6.3/bin/mvn -q test
```

Prefer `rg`/`rg --files` over slower search tools.

## Editing Rules For Continuation

- Use `apply_patch` for manual edits.
- Do not revert user/unrelated changes.
- Keep edits scoped to the requested migration batch.
- Run Maven tests after each batch.
- Update `MIGRATION.md` when completing a meaningful migration batch.
- Keep this file updated only when it helps future handoff context.
