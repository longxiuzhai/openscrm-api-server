package cn.openscrm.api.wework;

public interface WeWorkClient {

    String getAccessToken(String corpId, String secret);

    DepartmentListResponse listDepartments(String corpId, String secret);

    UserIdListResponse listUserIds(String corpId, String secret);

    UserDetailResponse getUser(String corpId, String secret, String userId);

    UserIdentityResponse getUserInfo(String corpId, String secret, String code);

    ExternalContactCorpTagListResponse listExternalContactCorpTags(String corpId, String secret, java.util.List<String> tagIds);

    GroupChatGetResponse getGroupChat(String corpId, String secret, String chatId);

    ContactWayAddResponse addContactWay(String corpId, String secret, ContactWayRequest request);

    ContactWayGetResponse getContactWay(String corpId, String secret, String configId);

    void updateContactWay(String corpId, String secret, ContactWayRequest request);

    void deleteContactWay(String corpId, String secret, String configId);

    void updateUserEnable(String corpId, String secret, String userId, int enable);
}
