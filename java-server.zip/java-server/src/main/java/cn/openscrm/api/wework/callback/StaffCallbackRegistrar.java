package cn.openscrm.api.wework.callback;

import cn.openscrm.api.config.OpenScrmProperties;
import cn.openscrm.api.staff.service.StaffService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Slf4j
@Component
@RequiredArgsConstructor
public class StaffCallbackRegistrar implements WeWorkCallbackRegistrar {

    private final StaffService staffService;
    private final OpenScrmProperties properties;

    @Override
    public void register(WeWorkCallbackService service) {
        service.register("event", "change_contact", "update_user", this::updateStaff);
    }

    private void updateStaff(WeWorkCallbackMessage message) {
        String extCorpId = StringUtils.hasText(message.getToUserName())
                ? message.getToUserName()
                : properties.getWeWork().getExtCorpId();
        String userId = message.getFields().get("UserID");
        if (!StringUtils.hasText(userId)) {
            log.warn("missing UserID in update_user callback fields={}", message.getFields());
            staffService.sync(extCorpId);
            return;
        }
        log.info("sync staff after update_user callback userId={}", userId);
        staffService.syncOne(extCorpId, userId);
    }
}
