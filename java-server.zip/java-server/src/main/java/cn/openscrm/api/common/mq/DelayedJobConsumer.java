package cn.openscrm.api.common.mq;

import cn.openscrm.api.config.RabbitMqConfig;
import cn.openscrm.api.contactway.service.ContactWayService;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class DelayedJobConsumer {

    private final ContactWayService contactWayService;

    public DelayedJobConsumer(ContactWayService contactWayService) {
        this.contactWayService = contactWayService;
    }

    @RabbitListener(queues = RabbitMqConfig.DELAYED_JOB_QUEUE)
    public void consume(Map<String, Object> payload) {
        String topic = string(payload.get("topic"));
        if (DelayedJobTopics.REFRESH_CONTACT_WAY.equals(topic)) {
            contactWayService.refresh(longValue(payload.get("id")), string(payload.get("extCorpId")));
            return;
        }
        if (DelayedJobTopics.SYNC_CUSTOMER_DATA.equals(topic)) {
            log.info("sync customer data job received but customer sync consumer is not migrated yet payload={}", payload);
            return;
        }
        log.warn("unknown delayed job topic={}, payload={}", topic, payload);
    }

    private String string(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private Long longValue(Object value) {
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        try {
            return value == null ? null : Long.valueOf(String.valueOf(value));
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
