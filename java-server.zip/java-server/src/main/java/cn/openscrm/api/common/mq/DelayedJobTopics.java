package cn.openscrm.api.common.mq;

public final class DelayedJobTopics {

    public static final String REFRESH_CONTACT_WAY = "topic:RefreshContactWayTopic";
    public static final String SYNC_CUSTOMER_DATA = "topic:SyncCustomerDataTopic";

    private DelayedJobTopics() {
    }
}
