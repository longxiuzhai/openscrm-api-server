package cn.openscrm.api.contactway.dto;

import cn.openscrm.api.persistence.entity.ContactWayGroupPo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactWayGroupResponse {

    private ContactWayGroupPo contactWayGroup;
    private Long count;

    public ContactWayGroupResponse(ContactWayGroupPo contactWayGroup, Long count) {
        this.contactWayGroup = contactWayGroup;
        this.count = count;
    }
}
