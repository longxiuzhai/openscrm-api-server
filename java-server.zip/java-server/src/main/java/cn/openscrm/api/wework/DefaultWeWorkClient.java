package cn.openscrm.api.wework;

import cn.openscrm.api.config.OpenScrmProperties;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class DefaultWeWorkClient implements WeWorkClient {

    private final OpenScrmProperties properties;
    private final RestTemplate restTemplate;
    private final StringRedisTemplate redisTemplate;

    public DefaultWeWorkClient(OpenScrmProperties properties, RestTemplate restTemplate, StringRedisTemplate redisTemplate) {
        this.properties = properties;
        this.restTemplate = restTemplate;
        this.redisTemplate = redisTemplate;
    }

    @Override
    public String getAccessToken(String corpId, String secret) {
        if (!StringUtils.hasText(corpId) || !StringUtils.hasText(secret)) {
            throw new WeWorkApiException(-1, "missing WeWork corp id or secret");
        }
        String cacheKey = "openscrm:wework:access-token:" + corpId + ":" + secret.hashCode();
        String cached = redisTemplate.opsForValue().get(cacheKey);
        if (cached != null && !cached.isEmpty()) {
            return cached;
        }
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/gettoken")
                .queryParam("corpid", corpId)
                .queryParam("corpsecret", secret)
                .toUriString();
        AccessTokenResponse response = getForObject(url, AccessTokenResponse.class);
        response.throwIfError();
        redisTemplate.opsForValue().set(cacheKey, response.getAccessToken(), ttl(response.getExpiresIn()));
        return response.getAccessToken();
    }

    @Override
    public DepartmentListResponse listDepartments(String corpId, String secret) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/department/list")
                .queryParam("access_token", token)
                .toUriString();
        DepartmentListResponse response = getForObject(url, DepartmentListResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public UserIdListResponse listUserIds(String corpId, String secret) {
        String token = getAccessToken(corpId, secret);
        String cursor = null;
        UserIdListResponse aggregate = new UserIdListResponse();
        do {
            String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                    .path("/cgi-bin/user/list_id")
                    .queryParam("access_token", token)
                    .queryParam("limit", 10000)
                    .queryParamIfPresent("cursor", java.util.Optional.ofNullable(cursor))
                    .toUriString();
            UserIdListResponse page = getForObject(url, UserIdListResponse.class);
            page.throwIfError();
            aggregate.getDeptUser().addAll(page.getDeptUser());
            cursor = page.getNextCursor();
        } while (cursor != null && !cursor.isEmpty());
        return aggregate;
    }

    @Override
    public UserDetailResponse getUser(String corpId, String secret, String userId) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/user/get")
                .queryParam("access_token", token)
                .queryParam("userid", userId)
                .toUriString();
        UserDetailResponse response = getForObject(url, UserDetailResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public UserIdentityResponse getUserInfo(String corpId, String secret, String code) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/user/getuserinfo")
                .queryParam("access_token", token)
                .queryParam("code", code)
                .toUriString();
        UserIdentityResponse response = getForObject(url, UserIdentityResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public ExternalContactCorpTagListResponse listExternalContactCorpTags(String corpId, String secret, List<String> tagIds) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/externalcontact/get_corp_tag_list")
                .queryParam("access_token", token)
                .toUriString();
        Map<String, Object> body = new HashMap<>();
        if (tagIds != null && !tagIds.isEmpty()) {
            body.put("tag_id", tagIds);
        }
        ExternalContactCorpTagListResponse response = postForObject(url, body, ExternalContactCorpTagListResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public GroupChatGetResponse getGroupChat(String corpId, String secret, String chatId) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/externalcontact/groupchat/get")
                .queryParam("access_token", token)
                .toUriString();
        Map<String, Object> body = new HashMap<>();
        body.put("chat_id", chatId);
        GroupChatGetResponse response = postForObject(url, body, GroupChatGetResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public ContactWayAddResponse addContactWay(String corpId, String secret, ContactWayRequest request) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/externalcontact/add_contact_way")
                .queryParam("access_token", token)
                .toUriString();
        ContactWayAddResponse response = postForObject(url, request, ContactWayAddResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public ContactWayGetResponse getContactWay(String corpId, String secret, String configId) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/externalcontact/get_contact_way")
                .queryParam("access_token", token)
                .toUriString();
        Map<String, Object> body = new HashMap<>();
        body.put("config_id", configId);
        ContactWayGetResponse response = postForObject(url, body, ContactWayGetResponse.class);
        response.throwIfError();
        return response;
    }

    @Override
    public void updateContactWay(String corpId, String secret, ContactWayRequest request) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/externalcontact/update_contact_way")
                .queryParam("access_token", token)
                .toUriString();
        CommonResponse response = postForObject(url, request, CommonResponse.class);
        response.throwIfError();
    }

    @Override
    public void deleteContactWay(String corpId, String secret, String configId) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/externalcontact/del_contact_way")
                .queryParam("access_token", token)
                .toUriString();
        Map<String, Object> body = new HashMap<>();
        body.put("config_id", configId);
        CommonResponse response = postForObject(url, body, CommonResponse.class);
        response.throwIfError();
    }

    @Override
    public void updateUserEnable(String corpId, String secret, String userId, int enable) {
        String token = getAccessToken(corpId, secret);
        String url = UriComponentsBuilder.fromHttpUrl(properties.getWeWork().getApiHost())
                .path("/cgi-bin/user/update")
                .queryParam("access_token", token)
                .toUriString();
        Map<String, Object> body = new HashMap<>();
        body.put("userid", userId);
        body.put("enable", enable);
        CommonResponse response = postForObject(url, body, CommonResponse.class);
        response.throwIfError();
    }

    public OpenScrmProperties.WeWork config() {
        return properties.getWeWork();
    }

    private Duration ttl(Integer expiresIn) {
        int seconds = expiresIn == null ? 7200 : expiresIn;
        return Duration.ofSeconds(Math.max(60, seconds - 300));
    }

    private <T> T getForObject(String url, Class<T> clazz) {
        try {
            return restTemplate.getForObject(url, clazz);
        } catch (RestClientException e) {
            throw new WeWorkApiException(-1, e.getMessage());
        }
    }

    private <T> T postForObject(String url, Object body, Class<T> clazz) {
        try {
            return restTemplate.postForObject(url, body, clazz);
        } catch (RestClientException e) {
            throw new WeWorkApiException(-1, e.getMessage());
        }
    }
}
