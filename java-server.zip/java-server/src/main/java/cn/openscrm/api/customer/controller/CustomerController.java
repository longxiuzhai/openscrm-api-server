package cn.openscrm.api.customer.controller;

import cn.openscrm.api.auth.annotation.RequirePermission;
import cn.openscrm.api.common.api.ApiResponse;
import cn.openscrm.api.common.api.PageResponse;
import cn.openscrm.api.common.constant.BizIdentity;
import cn.openscrm.api.common.constant.OperationType;
import cn.openscrm.api.customer.entity.CustomerEntity;
import cn.openscrm.api.customer.service.CustomerService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/staff-admin")
public class CustomerController {

    private final CustomerService customerService;

    @GetMapping("/customers")
    @RequirePermission(biz = BizIdentity.BIZ_CUSTOMER_INFO, operation = OperationType.READ)
    public ApiResponse<PageResponse<CustomerEntity>> list(
            @RequestParam(defaultValue = "1") @Min(1) long page,
            @RequestParam(defaultValue = "20") @Min(1) @Max(200) long pageSize) {
        IPage<CustomerEntity> result = customerService.page(page, pageSize);
        return ApiResponse.ok(new PageResponse<>(result.getRecords(), result.getTotal(), page, pageSize));
    }

    @GetMapping("/customer/{id}")
    @RequirePermission(biz = BizIdentity.BIZ_CUSTOMER_INFO, operation = OperationType.READ)
    public ApiResponse<CustomerEntity> get(@PathVariable Long id) {
        return ApiResponse.ok(customerService.getById(id));
    }
}
