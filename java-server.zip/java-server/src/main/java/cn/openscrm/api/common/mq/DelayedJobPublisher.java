package cn.openscrm.api.common.mq;

import cn.openscrm.api.config.RabbitMqConfig;
import java.time.Duration;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
public class DelayedJobPublisher {

    private final RabbitTemplate rabbitTemplate;

    public DelayedJobPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publish(Object payload, Duration delay) {
        MessagePostProcessor ttlProcessor = message -> {
            message.getMessageProperties().setExpiration(String.valueOf(delay.toMillis()));
            return message;
        };
        rabbitTemplate.convertAndSend(
                RabbitMqConfig.OPEN_SCRM_EXCHANGE,
                RabbitMqConfig.DELAYED_JOB_WAIT_ROUTING_KEY,
                payload,
                ttlProcessor
        );
    }
}
