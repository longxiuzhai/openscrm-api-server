# Go To Java Migration Plan

## Principles

The original Go service should stay available while the Java service is built module by module. Each migrated module should preserve the HTTP path, request shape, response envelope, database table, and permission behavior unless a change is explicitly accepted.

## Technology Replacement

| Original | Java Replacement |
| --- | --- |
| Gin | Spring MVC |
| GORM | MyBatis Plus |
| Viper YAML config | Spring Boot `application.yml` |
| Go Redis client | Spring Data Redis |
| Redis delay queue | RabbitMQ queue + retry/dead-letter design |
| Gin sessions in Redis | Spring Session Redis + JWT |
| Zap logging | Logback through Spring Boot |
| Go validator | Jakarta Validation |
| `pkg/easywework` | Java WeWork client module |
| OSS/COS storage wrappers | Spring service adapters for Aliyun OSS and Tencent COS |

## Migration Order

1. Infrastructure - done
   - Application bootstrap
   - Unified response envelope
   - Global exception handling
   - MyBatis Plus configuration
   - Redis/RabbitMQ configuration
   - Database schema import
   - Full table PO and Mapper generation

2. Authentication And Permission - in progress
   - Staff frontend session
   - Staff admin session
   - JWT issue/parse layer
   - Debug force-login only outside production
   - RBAC guard equivalent

3. Core Enterprise Data - next
   - Department
   - Staff
   - Role
   - Permission

4. Customer Domain
   - Customer
   - Customer info
   - Customer staff relation
   - Customer tags
   - Customer events

5. Marketing And Operations
   - Contact way
   - Welcome message
   - Quick reply
   - Material library
   - Mass message
   - Group chat modules

6. Callback, Async Jobs, And Tasks
   - WeWork callback verification/decryption
   - Event dispatch
   - RabbitMQ consumers with TTL + dead-letter delayed delivery
   - Scheduled jobs

7. Conversation Archive
   - Message archive API client
   - Message parsing
   - Media download
   - Search/query behavior

## Items Needing Confirmation

- Database migration tool: keep raw SQL, or introduce Flyway/Liquibase.
- File storage: keep Aliyun OSS and Tencent COS only, or enable local storage too.

## Confirmed Decisions

- Session strategy: Spring Session Redis + JWT.
- RabbitMQ delayed message style: TTL + dead-letter queues.
- Java WeWork client: port the current in-repo Go SDK behavior into Java.

## Completed Java Artifacts

- Spring Boot Java 11 project.
- Full schema at `src/main/resources/db/schema.sql`.
- 48 generated `*Po` entities under `cn.openscrm.api.persistence.entity`.
- 48 generated `*PoMapper` interfaces under `cn.openscrm.api.persistence.mapper`.
- Common and business error codes.
- Business exception and global exception handling.
- JWT token service.
- Spring Session Redis setup.
- RabbitMQ TTL + dead-letter delayed queue setup.
- WeWork client and callback migration placeholders.
- Staff admin/staff frontend force-login session entry points.
- RBAC annotation and Spring MVC permission interceptor.
- Permission and default role seed service.
- WeWork access token client with Redis cache.
- WeWork department list client.
- Department sync/query service and staff-admin department endpoints.
- WeWork staff ID list client.
- Staff sync service for staff and staff-department relations.
- Staff staff-admin sync/query/get/current endpoints.
- WeWork user detail client.
- Staff sync enriched with user detail fields.
- Staff enable/disable endpoint.
- Department tree get endpoint.
- WeWork OAuth `getuserinfo` client.
- Staff admin QR login URL/callback endpoints.
- Staff frontend H5 OAuth login URL/callback endpoints.
- Login callbacks write Spring Session and issue JWT responses.
- Role query/get/create/update/assign-staff/query-staffs APIs.
- Permission query/get APIs.
- Customer H5 login callback writes Spring Session and issues JWT response.
- Welcome message create/query/get/update/delete APIs.
- Department/staff welcome-message assignment helpers.
- WeWork callback URL verification, AES-CBC decryption, XML parsing, and event dispatch registry.
- WeWork department create/update/delete callback handlers.
- WeWork staff update callback handler with single-staff sync.
- WeWork customer relation callback handlers for add/edit/delete/del-follow events.
- Customer callback event records, customer statistics, relation soft-delete/history, and sync-job publish.
- WeWork external contact corp tag list client.
- WeWork tag create/update/delete callback handlers and local tag sync/delete cleanup.
- WeWork external group chat detail client.
- WeWork group-chat create/update/dismiss callback handlers and local group/member sync.
- Contact way group query/get/create/update/delete staff-admin APIs.
- WeWork contact-way add/get/update/delete client.
- Contact way query/get/create/update/delete/batch-update staff-admin APIs with staff, backup-staff, and schedule associations.
- Delayed job topic constants and RabbitMQ ready-queue dispatcher.
- Contact way delayed refresh job publishing/consumer.
- Contact way daily staff counter reset scheduled task.

## Next Manual Migration Batch

1. Port SyncCustomerDataTopic consumer: fetch external customer detail, customer-info, customer-staff relation, tags, and welcome message send flow.
2. Port contact way add-customer side effects: auto tag, customer remark/description, nickname block, welcome strategy, and staff daily count increments.
3. Port customer frontend current-session helpers if frontend routes need them.
4. Port welcome message upload-url/image-to-WeWork-media helpers.
5. Port group-chat query/management HTTP APIs.
6. Port material library, quick reply, mass message, group auto-join, and conversation archive modules.
