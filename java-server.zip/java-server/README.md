# OpenSCRM Java API Server

This directory is the Spring Boot rewrite track for the original Go API server.

## Stack

- Java 11
- Spring Boot 2.7
- MyBatis Plus
- MySQL
- Redis
- RabbitMQ
- Spring Session Redis
- JWT

## Mapping From The Go Project

- `app/controller` -> `controller`
- `app/services` -> `service`
- `app/models` -> `entity` + `mapper`
- `common/app` -> `common/api`
- `common/delay_queue` -> RabbitMQ delayed/retry queues
- `common/redis` and `common/session` -> Spring Data Redis + Spring Session Redis + JWT
- `pkg/easywework` -> Java WeWork client module to be implemented

## Current State

The project skeleton is in place and includes one migrated sample module:

- `customer`

The full schema generated from the Go GORM models is available at:

- `src/main/resources/db/schema.sql`

Business modules should be migrated one by one to keep behavior verifiable.
